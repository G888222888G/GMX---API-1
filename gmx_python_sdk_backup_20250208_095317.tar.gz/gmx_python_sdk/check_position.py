import sys
import os

# Add the parent directory to Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from gmx_python_sdk.scripts.v2.get.get_open_positions import GetOpenPositions
from gmx_python_sdk.scripts.v2.gmx_utils import ConfigManager
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def check_positions():
    try:
        # Initialize configuration
        logger.info("Initializing GMX configuration...")
        config = ConfigManager(chain='arbitrum')
        config.set_config()
        
        # Get positions using wallet address from config
        logger.info("Fetching positions...")
        positions = GetOpenPositions(
            config=config,
            address=config.user_wallet_address
        ).get_data()
        
        if positions:
            logger.info("\nOpen Positions:")
            for key, position in positions.items():
                logger.info(f"\nPosition: {key}")
                logger.info(f"Market: {position['market']}")
                logger.info(f"Size: ${float(position['position_size']):.2f}")
                logger.info(f"Collateral: ${float(position['inital_collateral_amount']):.2f}")
                logger.info(f"Entry Price: ${float(position['entry_price']):.2f}")
                logger.info(f"Leverage: {float(position['leverage']):.2f}x")
                logger.info(f"PnL: ${float(position['pnl']):.2f}")
                logger.info("------------------------")
        else:
            logger.info("No open positions found")
            
        return positions

    except Exception as e:
        logger.error(f"Error checking positions: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        logger.info("Checking positions...")
        check_positions()
        
    except Exception as e:
        logger.error(f"Failed to check positions: {str(e)}")
