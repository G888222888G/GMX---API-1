import sys
import os

def _set_paths():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_dir = os.path.join(current_dir, '../')
    sys.path.append(target_dir)

_set_paths()

from gmx_python_sdk.scripts.v2.approve_token_for_spend import check_if_approved
from gmx_python_sdk.scripts.v2.gmx_utils import ConfigManager, get_tokens_address_dict
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def approve_usdc():
    try:
        # Initialize configuration
        logger.info("Initializing GMX configuration...")
        config = ConfigManager(chain='arbitrum')
        config.set_config()
        
        # Get USDC token address
        tokens = get_tokens_address_dict('arbitrum')
        usdc_address = next(token['address'] for token in tokens.values() if token['symbol'] == 'USDC')
        
        # Get GMX router address
        router_address = "0x7452c558d45f8afC8c83dAe62C3f8A5BE19c71f6"  # GMX V2 Router
        
        # Amount to approve (5 USDC = 5000000)
        amount = 5000000
        
        logger.info("Checking and approving USDC...")
        check_if_approved(
            config=config,
            spender=router_address,
            token_to_approve=usdc_address,
            amount_of_tokens_to_spend=amount,
            max_fee_per_gas=None,  # Will use current gas price
            approve=True  # This will trigger approval if needed
        )
        
        logger.info("USDC approval process completed!")
        return True

    except Exception as e:
        logger.error(f"Error approving USDC: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        approve_usdc()
        
    except Exception as e:
        logger.error(f"Failed to approve USDC: {str(e)}")
