import sys
import os

def _set_paths():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_dir = os.path.join(current_dir, '../')
    sys.path.append(target_dir)

_set_paths()

from gmx_python_sdk.scripts.v2.gmx_utils import ConfigManager, create_connection, get_tokens_address_dict, convert_to_checksum_address
from web3 import Web3
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Basic ERC20 ABI for balanceOf
ERC20_ABI = [
    {
        "constant": True,
        "inputs": [{"name": "_owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "balance", "type": "uint256"}],
        "type": "function"
    }
]

def check_balances():
    try:
        # Initialize configuration
        logger.info("Initializing GMX configuration...")
        config = ConfigManager(chain='arbitrum')
        config.set_config()
        
        # Create connection
        connection = create_connection(config)
        
        # Get USDC token address
        tokens = get_tokens_address_dict('arbitrum')
        usdc_token = next(token for token in tokens.values() if token['symbol'] == 'USDC')
        usdc_address = convert_to_checksum_address(config, usdc_token['address'])
        
        # Create USDC contract instance
        usdc_contract = connection.eth.contract(
            address=usdc_address,
            abi=ERC20_ABI
        )
        
        # Convert wallet address to checksum
        wallet_address = convert_to_checksum_address(config, config.user_wallet_address)
        
        # Get ETH balance
        eth_balance = connection.eth.get_balance(wallet_address)
        eth_balance_in_eth = Web3.from_wei(eth_balance, 'ether')
        
        # Get USDC balance
        usdc_balance = usdc_contract.functions.balanceOf(wallet_address).call()
        usdc_balance_in_usdc = usdc_balance / 10**6  # USDC has 6 decimals
        
        logger.info(f"\nWallet Address: {wallet_address}")
        logger.info(f"ETH Balance: {eth_balance_in_eth:.4f} ETH")
        logger.info(f"USDC Balance: {usdc_balance_in_usdc:.2f} USDC")
        
        # Check if balances are sufficient
        if eth_balance_in_eth < 0.01:
            logger.warning("Warning: ETH balance might be too low for gas")
        if usdc_balance_in_usdc < 5:
            logger.warning("Warning: USDC balance is less than required 5 USDC")
        
        return {
            'eth_balance': eth_balance_in_eth,
            'usdc_balance': usdc_balance_in_usdc
        }

    except Exception as e:
        logger.error(f"Error checking balances: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        check_balances()
        
    except Exception as e:
        logger.error(f"Failed to check balances: {str(e)}")
