import sys
import os
import json

def _set_paths():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_dir = os.path.join(current_dir, '../')
    sys.path.append(target_dir)

_set_paths()

from gmx_python_sdk.scripts.v2.gmx_utils import ConfigManager, create_connection, get_tokens_address_dict, convert_to_checksum_address
from gmx_python_sdk.scripts.v2.get.get_open_positions import GetOpenPositions
from web3 import Web3
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_value(value):
    """Helper function to handle tuple values"""
    if isinstance(value, tuple):
        return value[0]
    return value

def monitor_position():
    try:
        # Initialize configuration
        logger.info("Initializing GMX configuration...")
        config = ConfigManager(chain='arbitrum')
        config.set_config()
        
        # Create connection
        connection = create_connection(config)
        
        # Get token addresses
        tokens = get_tokens_address_dict('arbitrum')
        usdc_token = next(token for token in tokens.values() if token['symbol'] == 'USDC')
        eth_token = next(token for token in tokens.values() if token['symbol'] == 'ETH')
        
        # Convert wallet address
        wallet_address = convert_to_checksum_address(config, config.user_wallet_address)
        logger.info("Checking for position...")
        
        # Get positions using SDK class
        positions_getter = GetOpenPositions(config, wallet_address)
        positions = positions_getter.get_data()  # Changed to get_data()
        
        if positions:
            for key, position in positions.items():  # Iterate over dictionary items
                logger.info("\nPosition found!")
                # Handle market_symbol tuple
                market_symbol = get_value(position['market_symbol'])
                logger.info(f"\nPosition: {market_symbol}_{'Long' if position['is_long'] else 'Short'}")
                logger.info(f"Market: {position['market']}")
                
                # Get position details
                size_usd = get_value(position['position_size'])  # Already in USD
                collateral_usd = get_value(position['inital_collateral_amount_usd'])  # Already in USD
                entry_price = get_value(position['entry_price'])  # Already in proper format
                
                # Get leverage and prices
                leverage = get_value(position['leverage'])
                mark_price = get_value(position['mark_price'])
                percent_profit = get_value(position['percent_profit'])
                
                logger.info(f"Size: ${float(size_usd):.2f}")
                logger.info(f"Collateral: ${float(collateral_usd):.2f}")
                logger.info(f"Entry Price: ${float(entry_price):.2f}")
                logger.info(f"Current Price: ${float(mark_price):.2f}")
                logger.info(f"Leverage: {float(leverage):.2f}x")
                logger.info(f"PnL: {float(percent_profit):.2f}%")
                
        else:
            logger.info("No positions open for address: " + f'"{wallet_address}"' + " on Arbitrum.")
            logger.info("No open positions found")
        
        return True

    except Exception as e:
        logger.error(f"Error checking position: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        monitor_position()
        
    except Exception as e:
        logger.error(f"Failed to check position: {str(e)}")
