import sys
import os
import json

def _set_paths():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_dir = os.path.join(current_dir, '../')
    sys.path.append(target_dir)

_set_paths()

from gmx_python_sdk.scripts.v2.gmx_utils import ConfigManager, create_connection, get_tokens_address_dict, convert_to_checksum_address, order_type
from gmx_python_sdk.scripts.v2.get.get_open_positions import GetOpenPositions
from gmx_python_sdk.scripts.v2.order.create_decrease_order import DecreaseOrder
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_value(value):
    """Helper function to handle tuple values"""
    if isinstance(value, tuple):
        return value[0]
    return value

def close_position():
    try:
        # Initialize configuration
        logger.info("Initializing GMX configuration...")
        config = ConfigManager(chain='arbitrum')
        config.set_config()
        
        # Create connection
        connection = create_connection(config)
        
        # Get token addresses
        tokens = get_tokens_address_dict('arbitrum')
        usdc_token = next(token for token in tokens.values() if token['symbol'] == 'USDC')
        eth_token = next(token for token in tokens.values() if token['symbol'] == 'ETH')
        
        # Get current position
        wallet_address = convert_to_checksum_address(config, config.user_wallet_address)
        positions_getter = GetOpenPositions(config, wallet_address)
        positions = positions_getter.get_data()
        
        if not positions:
            logger.info("No positions found to close")
            return False
            
        # Get the ETH long position
        position = next((pos for key, pos in positions.items() if 'ETH' in str(pos['market_symbol']) and pos['is_long']), None)
        if not position:
            logger.info("No ETH long position found to close")
            return False
            
        # Get position details with tuple handling
        size_usd = get_value(position['position_size'])
        collateral_usd = get_value(position['inital_collateral_amount_usd'])
            
        logger.info("Found position to close:")
        logger.info(f"Market: {position['market']}")
        logger.info(f"Size: ${float(size_usd):.2f}")
        logger.info(f"Collateral: ${float(collateral_usd):.2f}")
        
        # Get current gas price
        gas_price = connection.eth.gas_price
        max_fee_per_gas = int(gas_price * 1.5)  # 50% buffer
        
        # Create the close order
        logger.info("Creating close order...")
        order = DecreaseOrder(
            config=config,
            market_key=position['market'],
            collateral_address=usdc_token['address'],
            index_token_address=eth_token['address'],
            is_long=True,
            size_delta=int(size_usd * 1e30),  # Convert to correct format
            initial_collateral_delta_amount=int(collateral_usd * 1e6),  # Convert USDC to correct decimals
            slippage_percent=0.003,  # 0.3% slippage
            swap_path=[],  # Empty swap path for direct conversion
            debug_mode=False,  # Execute the actual order
            execution_buffer=2.0,  # Same buffer as open
            max_fee_per_gas=max_fee_per_gas  # Set max gas fee
        )
        
        # Execute the close order
        logger.info("Executing close order...")
        logger.info(f"Using max gas fee: {connection.from_wei(max_fee_per_gas, 'gwei')} Gwei")
        
        # The order will be built and executed automatically by DecreaseOrder
        logger.info("Close order submitted successfully!")
        return True

    except Exception as e:
        logger.error(f"Error closing position: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        logger.info("Starting position close...")
        close_position()
        
    except Exception as e:
        logger.error(f"Failed to close position: {str(e)}")
