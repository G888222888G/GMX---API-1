import sys
import os

def _set_paths():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_dir = os.path.join(current_dir, '../')
    sys.path.append(target_dir)

_set_paths()

from gmx_python_sdk.scripts.v2.gmx_utils import ConfigManager, create_connection, get_tokens_address_dict, convert_to_checksum_address
from gmx_python_sdk.scripts.v2.get.get_open_positions import GetOpenPositions
from web3 import Web3
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_value(value):
    """Helper function to handle tuple values"""
    if isinstance(value, tuple):
        return value[0]
    return value

def calculate_liquidation_price():
    try:
        # Initialize configuration
        logger.info("Initializing GMX configuration...")
        config = ConfigManager(chain='arbitrum')
        config.set_config()
        
        # Get current position
        wallet_address = convert_to_checksum_address(config, config.user_wallet_address)
        positions_getter = GetOpenPositions(config, wallet_address)
        positions = positions_getter.get_data()
        
        if not positions:
            logger.info("No positions found")
            return False
            
        # Get the ETH long position
        position = next((pos for key, pos in positions.items() if 'ETH' in str(pos['market_symbol']) and pos['is_long']), None)
        if not position:
            logger.info("No ETH long position found")
            return False
            
        # Get position details
        size_usd = get_value(position['position_size'])
        collateral_usd = get_value(position['inital_collateral_amount_usd'])
        entry_price = get_value(position['entry_price'])
        is_long = position['is_long']
            
        logger.info("\nPosition Details:")
        logger.info(f"Size: ${float(size_usd):.2f}")
        logger.info(f"Collateral: ${float(collateral_usd):.2f}")
        logger.info(f"Entry Price: ${float(entry_price):.2f}")
        logger.info(f"Direction: {'Long' if is_long else 'Short'}")
        
        # Calculate liquidation price
        # For 1x leverage (collateral = size), there is no liquidation price
        # as the position is fully collateralized
        # Compare with a small tolerance to account for floating point precision
        if abs(float(collateral_usd) - float(size_usd)) < 0.01:
            liquidation_price = 0
            logger.info("\nNo liquidation price - position is fully collateralized")
        else:
            # For higher leverage positions:
            # For a long position:
            # liquidation_price = entry_price * (1 - collateral_usd/size_usd)
            # For a short position:
            # liquidation_price = entry_price * (1 + collateral_usd/size_usd)
            if is_long:
                liquidation_price = float(entry_price) * (1 - float(collateral_usd)/float(size_usd))
            else:
                liquidation_price = float(entry_price) * (1 + float(collateral_usd)/float(size_usd))
            logger.info(f"\nLiquidation Price: ${liquidation_price:.2f}")
            
        # Show current price
        current_price = get_value(position['mark_price'])
        logger.info(f"Current Price: ${float(current_price):.2f}")
        
        # Calculate distance to liquidation only if there is a liquidation price
        if liquidation_price > 0:
            if is_long:
                distance_to_liq = ((float(current_price) - liquidation_price) / float(current_price)) * 100
            else:
                distance_to_liq = ((liquidation_price - float(current_price)) / float(current_price)) * 100
            logger.info(f"Distance to Liquidation: {distance_to_liq:.2f}%")
        
        return True

    except Exception as e:
        logger.error(f"Error calculating liquidation price: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        logger.info("Getting liquidation price...")
        calculate_liquidation_price()
        
    except Exception as e:
        logger.error(f"Failed to get liquidation price: {str(e)}")
