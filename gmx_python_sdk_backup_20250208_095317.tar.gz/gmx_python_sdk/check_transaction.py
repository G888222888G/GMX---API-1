import sys
import os

def _set_paths():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_dir = os.path.join(current_dir, '../')
    sys.path.append(target_dir)

_set_paths()

from gmx_python_sdk.scripts.v2.gmx_utils import ConfigManager, create_connection, convert_to_checksum_address
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def check_latest_transaction():
    try:
        # Initialize configuration
        logger.info("Initializing GMX configuration...")
        config = ConfigManager(chain='arbitrum')
        config.set_config()
        
        # Create connection
        connection = create_connection(config)
        
        # Convert wallet address to checksum
        wallet_address = convert_to_checksum_address(config, config.user_wallet_address)
        
        # Get latest nonce
        current_nonce = connection.eth.get_transaction_count(wallet_address)
        
        # Get the last transaction
        if current_nonce > 0:
            last_nonce = current_nonce - 1
            logger.info(f"Checking transaction with nonce {last_nonce}...")
            
            # Get pending transactions for the address
            block = connection.eth.get_block('latest')
            latest_block_number = block.number
            
            # Look back through last few blocks
            for block_number in range(latest_block_number, latest_block_number - 10, -1):
                block = connection.eth.get_block(block_number, True)
                for tx in block.transactions:
                    if tx['from'].lower() == wallet_address.lower():
                        logger.info("\nLatest Transaction Details:")
                        logger.info(f"Hash: {tx.hash.hex()}")
                        logger.info(f"From: {tx['from']}")
                        logger.info(f"To: {tx['to']}")
                        logger.info(f"Value: {connection.from_wei(tx['value'], 'ether')} ETH")
                        logger.info(f"Gas Price: {connection.from_wei(tx['gasPrice'], 'gwei')} Gwei")
                        logger.info(f"Gas Used: {tx['gas']}")
                        logger.info(f"Nonce: {tx['nonce']}")
                        logger.info(f"Block Number: {block_number}")
                        
                        receipt = connection.eth.get_transaction_receipt(tx.hash)
                        logger.info(f"Status: {'Success' if receipt['status'] == 1 else 'Failed'}")
                        logger.info(f"Gas Used: {receipt['gasUsed']}")
                        
                        # Check if transaction failed
                        if receipt['status'] == 0:
                            logger.warning("Transaction failed - likely due to insufficient ETH for gas")
                        return
                        
            logger.info("No recent transactions found")
        else:
            logger.info("No transactions found for this address")

    except Exception as e:
        logger.error(f"Error checking transaction: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        check_latest_transaction()
        
    except Exception as e:
        logger.error(f"Failed to check transaction: {str(e)}")
