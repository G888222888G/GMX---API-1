import sys
import os

def _set_paths():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_dir = os.path.join(current_dir, '../')
    sys.path.append(target_dir)

_set_paths()

from gmx_python_sdk.scripts.v2.gmx_utils import ConfigManager, create_connection, get_tokens_address_dict, convert_to_checksum_address
import logging
import json

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def check_order_status():
    try:
        # Initialize configuration
        logger.info("Initializing GMX configuration...")
        config = ConfigManager(chain='arbitrum')
        config.set_config()
        
        # Create connection
        connection = create_connection(config)
        
        # Get token addresses
        tokens = get_tokens_address_dict('arbitrum')
        usdc_token = next(token for token in tokens.values() if token['symbol'] == 'USDC')
        eth_token = next(token for token in tokens.values() if token['symbol'] == 'ETH')
        
        # Convert wallet address
        wallet_address = convert_to_checksum_address(config, config.user_wallet_address)
        logger.info(f"Checking orders for address: {wallet_address}")
        
        # Get GMX Reader contract
        reader_abi = json.load(open(os.path.join(
            os.path.dirname(__file__),
            'contracts',
            'reader.json'
        )))
        reader_address = "0xf60becbba223EEA9495Da3f606753867eC10d139"  # GMX V2 Reader
        reader = connection.eth.contract(address=reader_address, abi=reader_abi)
        
        # Get market info
        market_key = "0x70d95587d40A2caf56bd97485aB3Eec10Bee6336"  # ETH market
        
        # Get order info
        order_info = reader.functions.getOrder(
            market_key,
            wallet_address,
            0  # Order index
        ).call()
        
        logger.info("\nOrder Info:")
        logger.info(f"Account: {order_info[0]}")
        logger.info(f"Market: {order_info[1]}")
        logger.info(f"Order Type: {order_info[2]}")
        logger.info(f"Decrease Position Requested: {order_info[3]}")
        logger.info(f"Size Delta USD: {order_info[4]}")
        logger.info(f"Initial Collateral Delta: {order_info[5]}")
        logger.info(f"Trigger Price: {order_info[6]}")
        logger.info(f"Acceptable Price: {order_info[7]}")
        logger.info(f"Execution Fee: {order_info[8]}")
        logger.info(f"Callback Gas Limit: {order_info[9]}")
        logger.info(f"Min Output Amount: {order_info[10]}")
        logger.info(f"Updated At: {order_info[11]}")
        
        return True

    except Exception as e:
        logger.error(f"Error checking order status: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        check_order_status()
        
    except Exception as e:
        logger.error(f"Failed to check order status: {str(e)}")
