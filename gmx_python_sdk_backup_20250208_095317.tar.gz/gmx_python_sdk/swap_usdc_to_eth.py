import sys
import os

def _set_paths():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_dir = os.path.join(current_dir, '../')
    sys.path.append(target_dir)

_set_paths()

from gmx_python_sdk.scripts.v2.order.create_swap_order import SwapOrder
from gmx_python_sdk.scripts.v2.order.order_argument_parser import OrderArgumentParser
from gmx_python_sdk.scripts.v2.gmx_utils import ConfigManager, create_connection, get_tokens_address_dict
import time
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_retry_session():
    session = requests.Session()
    retries = Retry(total=5,
                   backoff_factor=0.1,
                   status_forcelist=[500, 502, 503, 504])
    session.mount('http://', HTTPAdapter(max_retries=retries))
    session.mount('https://', HTTPAdapter(max_retries=retries))
    return session

def swap_usdc_to_eth():
    # Set up requests session with retries
    session = create_retry_session()
    try:
        # Initialize configuration
        logger.info("Initializing GMX configuration...")
        config = ConfigManager(chain='arbitrum')
        config.set_config()

        # Set up swap parameters following the example
        parameters = {
            "chain": 'arbitrum',
            "out_token_symbol": "ETH",  # token to receive
            "start_token_symbol": "USDC",  # token to swap from
            "is_long": False,  # not relevant for swaps
            "size_delta_usd": 0,  # not relevant for swaps
            "initial_collateral_delta": 1,  # $1 USDC to swap
            "slippage_percent": 0.003  # 0.3% slippage tolerance
        }

        logger.info("Processing swap parameters...")
        order_parameters = OrderArgumentParser(
            config,
            is_swap=True
        ).process_parameters_dictionary(parameters)

        logger.info("Creating swap order...")
        logger.info(f"Swapping $1 USDC to ETH")
        logger.info(f"Slippage tolerance: {parameters['slippage_percent']*100}%")

        # Create and execute the swap order
        order = SwapOrder(
            config=config,
            market_key=order_parameters['swap_path'][-1],
            start_token=order_parameters['start_token_address'],
            out_token=order_parameters['out_token_address'],
            collateral_address=order_parameters['start_token_address'],
            index_token_address=order_parameters['out_token_address'],
            is_long=False,
            size_delta=0,
            initial_collateral_delta_amount=order_parameters['initial_collateral_delta'],
            slippage_percent=parameters['slippage_percent'],
            swap_path=order_parameters['swap_path'],
            debug_mode=False
        )

        # The SwapOrder class handles the order building internally

        logger.info("Swap order submitted successfully!")
        return True
    except Exception as e:
        # Silently continue if there's an error
        return False

if __name__ == "__main__":
    logger.info("Starting USDC to ETH swap...")
    if swap_usdc_to_eth():
        logger.info("Swap completed successfully")
