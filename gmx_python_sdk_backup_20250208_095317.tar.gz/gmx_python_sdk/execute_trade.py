import sys
import os

def _set_paths():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_dir = os.path.join(current_dir, '../')
    sys.path.append(target_dir)

_set_paths()

from gmx_python_sdk.scripts.v2.order.order_argument_parser import OrderArgumentParser
from gmx_python_sdk.scripts.v2.order.create_increase_order import IncreaseOrder
from gmx_python_sdk.scripts.v2.gmx_utils import ConfigManager, create_connection, order_type, get_tokens_address_dict
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def execute_eth_long():
    try:
        # Initialize configuration
        logger.info("Initializing GMX configuration...")
        config = ConfigManager(chain='arbitrum')
        config.set_config()
        
        # Get token addresses
        tokens = get_tokens_address_dict('arbitrum')
        usdc_token = next(token for token in tokens.values() if token['symbol'] == 'USDC')
        eth_token = next(token for token in tokens.values() if token['symbol'] == 'ETH')
        
        logger.info(f"USDC Address: {usdc_token['address']}")
        logger.info(f"ETH Address: {eth_token['address']}")
        
        # Set up trade parameters
        parameters = {
            "chain": 'arbitrum',
            "index_token_symbol": "ETH",
            "collateral_token_symbol": "USDC",
            "start_token_symbol": "USDC",
            "is_long": True,
            "size_delta_usd": 5,  # $5 position size
            "initial_collateral_delta": 5,  # $5 collateral (no leverage)
            "leverage": 1,  # No leverage
            "slippage_percent": 0.003,  # 0.3% slippage
            "order_type": order_type['market_increase']  # Explicitly set market order
        }
        
        logger.info("Processing order parameters...")
        order_parameters = OrderArgumentParser(
            config,
            is_increase=True
        ).process_parameters_dictionary(parameters)
        
        # Create the order
        logger.info("Creating long position...")
        logger.info(f"Market Key: {order_parameters['market_key']}")
        logger.info(f"Collateral Address: {order_parameters['start_token_address']}")
        logger.info(f"Index Token Address: {order_parameters['index_token_address']}")
        logger.info(f"Size Delta: {order_parameters['size_delta']}")
        logger.info(f"Initial Collateral: {order_parameters['initial_collateral_delta']}")
        logger.info(f"Order Type: {parameters['order_type']}")
        
        # Get current gas price
        connection = create_connection(config)
        gas_price = connection.eth.gas_price
        max_fee_per_gas = int(gas_price * 1.5)  # 50% buffer
        
        order = IncreaseOrder(
            config=config,
            market_key=order_parameters['market_key'],
            collateral_address=order_parameters['start_token_address'],
            index_token_address=order_parameters['index_token_address'],
            is_long=order_parameters['is_long'],
            size_delta=order_parameters['size_delta'],
            initial_collateral_delta_amount=order_parameters['initial_collateral_delta'],
            slippage_percent=order_parameters['slippage_percent'],
            swap_path=[],  # Empty swap path for direct USDC->ETH
            debug_mode=False,  # Execute the actual order
            execution_buffer=2.0,  # Increased to 2.0 as requested
            max_fee_per_gas=max_fee_per_gas  # Set max gas fee
        )
        
        # Build and execute the order
        logger.info("Building and executing order...")
        logger.info(f"Using max gas fee: {connection.from_wei(max_fee_per_gas, 'gwei')} Gwei")
        
        # Build the order
        order.order_builder(is_open=True)
        
        logger.info("Order submitted successfully!")
        return True

    except Exception as e:
        logger.error(f"Error executing trade: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        logger.info("Starting ETH long trade execution...")
        execute_eth_long()
        
    except Exception as e:
        logger.error(f"Failed to execute trade: {str(e)}")
