import sys
import os

# Add the parent directory to Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from gmx_python_sdk.scripts.v2.get.get_orders import GetOrders
from gmx_python_sdk.scripts.v2.gmx_utils import ConfigManager
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def check_orders():
    try:
        # Initialize configuration
        logger.info("Initializing GMX configuration...")
        config = ConfigManager(chain='arbitrum')
        config.set_config()
        
        # Get pending orders
        logger.info("Fetching pending orders...")
        orders = GetOrders(
            config=config,
            address=config.user_wallet_address
        ).get_data()
        
        if orders:
            logger.info("\nPending Orders:")
            for key, order in orders.items():
                logger.info(f"\nOrder: {key}")
                logger.info(f"Market: {order.get('market', 'N/A')}")
                logger.info(f"Type: {order.get('order_type', 'N/A')}")
                logger.info(f"Status: {order.get('status', 'N/A')}")
                logger.info(f"Size: ${float(order.get('size_delta', 0)):.2f}")
                logger.info(f"Collateral: ${float(order.get('initial_collateral_delta_amount', 0)):.2f}")
                logger.info("------------------------")
        else:
            logger.info("No pending orders found")
            
        return orders

    except Exception as e:
        logger.error(f"Error checking orders: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        logger.info("Checking order status...")
        check_orders()
        
    except Exception as e:
        logger.error(f"Failed to check orders: {str(e)}")
